function fetchAttendance() {
    fetch('/data')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById('attendance-list');
            tableBody.innerHTML = "";
            data.forEach(row => {
                const tr = document.createElement('tr');
                tr.innerHTML = `<td>${row[0]}</td><td>${row[1]}</td>`;
                tableBody.appendChild(tr);
            });
        });
}

setInterval(fetchAttendance, 5000);
fetchAttendance();

