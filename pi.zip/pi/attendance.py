import subprocess
import pymysql
from datetime import datetime
from flask import Flask, render_template, jsonify

# === CONFIGURATION ===
ROOT_PASSWORD = "raspberry"  # Mets ici le mot de passe root
WIFI_INTERFACE = "wlan0"  # Change si ton interface a un autre nom

# Configuration MySQL
db_config = {
    "host": "localhost",
    "user": "pi",
    "password": "raspberry",
    "database": "attendance_db"
}

app = Flask(__name__)

# === FONCTIONS ===
def run_command(cmd):
    """Exécute une commande shell avec sudo en injectant le mot de passe root."""
    full_cmd = f"echo {ROOT_PASSWORD} | sudo -S {cmd}"
    return subprocess.run(full_cmd, shell=True, text=True, capture_output=True)

def configure_monitor_mode():
    """Configure le Wi-Fi en mode moniteur."""
    print("🔄 Mise en mode moniteur...")
    run_command("airmon-ng check kill")
    run_command(f"airmon-ng start {WIFI_INTERFACE}")
    print("✅ Mode moniteur activé !")

def save_mac(mac_address):
    """Enregistre une adresse MAC avec l'heure actuelle dans MySQL."""
    try:
        connection = pymysql.connect(**db_config)
        cursor = connection.cursor()
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cursor.execute("INSERT INTO attendance (mac_address, timestamp) VALUES (%s, %s)", (mac_address, timestamp))
        connection.commit()
        connection.close()
        print(f"MAC enregistrée : {mac_address} à {timestamp}")
    except Exception as e:
        print(f"⚠️ Erreur de base de données : {e}")

# === CONFIGURATION & CAPTURE ===
configure_monitor_mode()

tshark_cmd = ["tshark", "-i", f"{WIFI_INTERFACE}mon", "-Y", "wlan.fc.type_subtype == 4", "-T", "fields", "-e", "wlan.sa"]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/data')
def get_data():
    """Récupère les données de présence pour affichage en temps réel."""
    try:
        connection = pymysql.connect(**db_config)
        cursor = connection.cursor()
        cursor.execute("SELECT mac_address, timestamp FROM attendance ORDER BY timestamp DESC LIMIT 50")
        data = cursor.fetchall()
        connection.close()
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    process = subprocess.Popen(tshark_cmd, stdout=subprocess.PIPE, text=True)
    try:
        for line in iter(process.stdout.readline, ""):
            mac = line.strip()
            if mac:
                save_mac(mac)
    except KeyboardInterrupt:
        process.terminate()
    app.run(host="0.0.0.0", port=5000, debug=True)

